<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to the login page
    header("Location: login.html");
    exit();
}

// Get user information from session variables, ensuring they are set
$befa =  $_SESSION['befa'];
$java =  $_SESSION['java'];
$os = $_SESSION['os'];
$dbms = $_SESSION['dbms'];
$dm =  $_SESSION['dm'];
$id =  $_SESSION['id'];
$name =  $_SESSION['name'];
$total =  $_SESSION['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="scss.css">
    <style>
        .chart-container {
            position: relative;
            width: 80%;
            max-width: 800px;
            margin: 20px auto;
           
            padding: 40px;
         
        }

        canvas {
            display: block;
        }
    </style>
</head>
<body>
    <div class="student">
        <nav>
            <h1>Student Dashboard</h1>
            <ul>
                <li><a href="sstudent.php">Student</a></li>
                <li><a href="sattendence.php">Attendance</a></li>
                <li><a href="sper.php">Performance</a></li>
                <li><a href="snotice.php">Notice</a></li>
                <li><a href="sfeedback.php">Feedback</a></li>
                <li><button type="button" onclick="logout()">LogOut</button></li>
            </ul>
        </nav>
        <h2>Dashboard</h2>
        <script src="logout.js"></script>
    </div>
    <div class="container mt-5">
        <table class="table table-striped text-center mx-auto" style="width: auto;">
            <thead>
                <tr>
                    <th scope="col">SI No</th>
                    <th scope="col">Id</th>
                    <th scope="col">NAME</th>
                    <th scope="col">JAVA</th>
                    <th scope="col">DBMS</th>
                    <th scope="col">DM</th>
                    <th scope="col">BEFA</th>
                    <th scope="col">OS</th>
                    <th scope="col">TotalMarks</th>
                    
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td><?php echo htmlspecialchars($id); ?></td>
                    <td><?php echo htmlspecialchars($name); ?></td>
                    <td><?php echo htmlspecialchars($java); ?></td>
                    <td><?php echo htmlspecialchars($dbms); ?></td>
                    <td><?php echo htmlspecialchars($dm); ?></td>
                    <td><?php echo htmlspecialchars($befa); ?></td>
                    <td><?php echo htmlspecialchars($os); ?></td>
                    <td><?php echo htmlspecialchars($os+$befa+$dbms+$java+$dm); ?></td>

                </tr>
            </tbody>
        </table>
    </div>
    <div class="chart-container">
        <canvas id="marksChart"></canvas>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Use session data to create the chart
        const labels = ['Java', 'DBMS', 'DM', 'BEFA', 'OS'];
        const data = {
            labels: labels,
            datasets: [{
                label: 'Marks',
                data: [<?php echo $java; ?>, <?php echo $dbms; ?>, <?php echo $dm; ?>, <?php echo $befa; ?>, <?php echo $os; ?>],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        };

        const config = {
            type: 'pie',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top', // Position legend at the top
                    }
                }
            }
        };

        const marksChart = new Chart(
            document.getElementById('marksChart'),
            config
        );
    </script>
</body>
</html>


