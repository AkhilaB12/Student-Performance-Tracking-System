<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="scss.css"> <!-- Ensure this path is correct -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .content {
            flex-grow: 1; /* Take up remaining space */
            display: flex;
            justify-content: center; /* Center align content horizontally */
            padding-top: 100px; /* Add padding */
            padding-right: 0px;
        }

        #noticeBoard {
            display: flex;
            flex-wrap: wrap; /* Allow multiple rows */
            justify-content: center; /* Center align content horizontally */
            align-items: flex-start; /* Align items to the top */
            max-width: 1000px; /* Set maximum width for notice board */
            background-color: #f9f9f9; /* Notice board background color */
            padding: 20px; /* Add padding */
            border-radius: 10px; /* Add border radius */
        }

        .notice {
            flex: 0 0 calc(33.333% - 20px); /* Three notices per row with margin in between */
            margin: 10px; /* Margin between notices */
            border: 1px solid #ccc; /* Notice border */
            padding: 10px; /* Notice padding */
            background-color: #fff;
            border-radius: 5px; /* Notice border radius */
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1); /* Add subtle shadow */
            transition: transform 0.3s ease;
            position: relative; /* Position relative for the container */
            overflow: hidden; /* Hide overflow for proper positioning */
        }

        .notice:hover {
            transform: scale(1.05);
        }

        .notice h3 {
            margin-top: 0;
            font-size: 1.2rem;
        }

        .notice p {
            margin: 0;
        }

        .date {
            font-style: italic;
            color: #777;
        }

        .deleteButton {
            position: absolute; 
            top: 5px; 
            right: 0px; /* Adjust right position */
            font-size: 1.5em; /* Adjust font size */
            color: red;
            background: none;
            border:none;
            cursor: pointer;
            
        }

    </style>
</head>
<body>
    <nav>
        <h1>Student Dashboard</h1>
        <ul>
          
            <li><a href="sstudent.php">Student</a></li>
            <li><a href="sattendence.php">Attendance</a></li>
            <li><a href="sper.php">Performance</a></li>
            <li><a href="snotice.php">Notice</a></li>
            <li><a href="sfeedback.php">Feedback</a></li>
            <li><button type="button" onclick="logout()">LogOut</button></li>
        </ul>
    </nav>
    <div class="content">
        <div class="student">
            <div id="noticeBoard">
                <!-- Notices added dynamically here -->
            </div>
        </div>
    </div>

    <script>
        // Retrieve notices from local storage and display them
        var notices = localStorage.getItem('notices') ? JSON.parse(localStorage.getItem('notices')) : [];
        var noticeBoard = document.getElementById('noticeBoard');
        notices.forEach(function(notice) {
            var noticeDiv = document.createElement('div');
            noticeDiv.classList.add('notice');
            noticeDiv.innerHTML = '<h6>New Notice</h6><p>' + notice.text + '</p><p class="date">Posted on: ' + notice.date + '</p>';
            
            // Create a delete button
            var deleteButton = document.createElement('button');
            deleteButton.classList.add('deleteButton');
            deleteButton.innerHTML = '<i class="fa fa-trash-o" aria-hidden="true"></i>'; // Font Awesome icon for trash can
            deleteButton.addEventListener('click', function() {
                // Call deleteNotice function passing index
                deleteNotice(i);
            });
            noticeDiv.appendChild(deleteButton);

            noticeBoard.appendChild(noticeDiv);
        });

        function logout() {
            
            // Add your logout logic here
            alert('Logout functionality not implemented.');
        }
    </script>
    <script src="logout.js"></script>
    <script>
  // Function to delete a notice by its index
function deleteNotice(index) {
    notices.splice(index, 1); // Remove the notice from the notices array
    renderNotices(); // Update the notice board to reflect the changes
    saveNoticesToLocalStorage(); // Save the updated notices to local storage
}

// Function to render notices on the notice board
function renderNotices() {
    // Clear existing content
    noticeBoard.innerHTML = '';

    // Loop through notices in reverse order to display newer notices first
    for (var i = notices.length - 1; i >= 0; i--) {
        var notice = notices[i];
        var noticeDiv = document.createElement('div');
        noticeDiv.classList.add('notice');
        noticeDiv.innerHTML = '<h6>New Notice</h6><p>' + notice.text + '</p><p class="date">Posted on: ' + notice.date + '</p>';

        // Create a delete button
        var deleteButton = document.createElement('button');
        deleteButton.classList.add('deleteButton');
        deleteButton.innerHTML = '<i style="font-size:24px" class="fa">&#xf014;</i>'; // Delete emoji or symbol
        deleteButton.addEventListener('click', deleteNotice.bind(null, i)); // Bind index to the delete function
        noticeDiv.appendChild(deleteButton);

        noticeBoard.appendChild(noticeDiv);
    }
}

// Function to save notices to local storage
function saveNoticesToLocalStorage() {
    localStorage.setItem('notices', JSON.stringify(notices));
}

// Retrieve notices from local storage and display them
var notices = localStorage.getItem('notices') ? JSON.parse(localStorage.getItem('notices')) : [];
var noticeBoard = document.getElementById('noticeBoard');

// Render notices on the notice board
renderNotices();

</script>
</body>
</html>
