<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="scss.css">
    <link rel="stylesheet" href="fed.css">
    <style>
        .emojis {
            display: inline-block;
            vertical-align: top; /* Aligns items to the top */
            margin-right: 20px; /* Adjust margin as needed */
        }
        .emojis .subject {
            float: left; /* Float subject name to the left */
            margin-right: 10px; /* Adjust margin as needed */
        }
        .emojis .emoji {
            display: inline-block; /* Display emojis inline */
        }
    </style>
</head>
<body>
    <div class="student">
        <nav>
            <h1>Student Dashboard</h1>
            <ul>
                <li><a href="sstudent.php">Student</a></li>
                <li><a href="sattendence.php">Attendance</a></li>
                <li><a href="sper.php">Performance</a></li>
                <li><a href="snotice.php">Notice</a></li>
                <li><a href="sfeedback.php">Feedback</a></li>
                <li><button type="button" onclick="logout()">LogOut</button></li>
            </ul>
        </nav>
    </div>
    <div class="teacher-feedback">
        <div class="teacher">
          <div class="teacher-name">DM</div>
          <div class="emojis" id="teacher1">
            <i class="emoji emoji-sad-cry far fa-sad-cry" onclick="submitFeedback('teacher1', '😢')"></i>
            <i class="emoji emoji-frown far fa-frown" onclick="submitFeedback('teacher1', '😟')"></i>
            <i class="emoji emoji-meh far fa-meh" onclick="submitFeedback('teacher1', '😐')"></i>
            <i class="emoji emoji-smile far fa-smile" onclick="submitFeedback('teacher1', '😊')"></i>
            <i class="emoji emoji-laugh far fa-laugh" onclick="submitFeedback('teacher1', '😍')"></i>
          </div>
        </div>
      
        <div class="teacher">
          <div class="teacher-name">Java</div>
          <div class="emojis" id="teacher2">
            <i class="emoji emoji-sad-cry far fa-sad-cry" onclick="submitFeedback('teacher2', '😢')"></i>
            <i class="emoji emoji-frown far fa-frown" onclick="submitFeedback('teacher2', '😟')"></i>
            <i class="emoji emoji-meh far fa-meh" onclick="submitFeedback('teacher2', '😐')"></i>
            <i class="emoji emoji-smile far fa-smile" onclick="submitFeedback('teacher2', '😊')"></i>
            <i class="emoji emoji-laugh far fa-laugh" onclick="submitFeedback('teacher2', '😍')"></i>
          </div>
        </div>
      
        <div class="teacher">
          <div class="teacher-name">OS</div>
          <div class="emojis" id="teacher3">
            <i class="emoji emoji-sad-cry far fa-sad-cry" onclick="submitFeedback('teacher3', '😢')"></i>
            <i class="emoji emoji-frown far fa-frown" onclick="submitFeedback('teacher3', '😟')"></i>
            <i class="emoji emoji-meh far fa-meh" oncli=ck="submitFeedback('teacher3', '😐')"></i>
            <i class="emoji emoji-smile far fa-smile" onclick="submitFeedback('teacher3', '😊')"></i>
            <i class="emoji emoji-laugh far fa-laugh" onclick="submitFeedback('teacher3', '😍')"></i>
          </div>
        </div>
      
        <div class="teacher">
          <div class="teacher-name">DBMS</div>
          <div class="emojis" id="teacher4">
            <i class="emoji emoji-sad-cry far fa-sad-cry" onclick="submitFeedback('teacher4', '😢')"></i>
            <i class="emoji emoji-frown far fa-frown" onclick="submitFeedback('teacher4', '😟')"></i>
            <i class="emoji emoji-meh far fa-meh" onclick="submitFeedback('teacher4', '😐')"></i>
            <i class="emoji emoji-smile far fa-smile" onclick="submitFeedback('teacher4', '😊')"></i>
            <i class="emoji emoji-laugh far fa-laugh" onclick="submitFeedback('teacher4', '😍')"></i>
          </div>
        </div>
        <div class="teacher">
            <div class="teacher-name">BEFA</div>
            <div class="emojis" id="teacher4">
              <i class="emoji emoji-sad-cry far fa-sad-cry" onclick="submitFeedback('teacher4', '😢')"></i>
              <i class="emoji emoji-frown far fa-frown" onclick="submitFeedback('teacher4', '😟')"></i>
              <i class="emoji emoji-meh far fa-meh" onclick="submitFeedback('teacher4', '😐')"></i>
              <i class="emoji emoji-smile far fa-smile" onclick="submitFeedback('teacher4', '😊')"></i>
              <i class="emoji emoji-laugh far fa-laugh" onclick="submitFeedback('teacher4', '😍')"></i>
            </div>
          </div>
      </div>
      <script src="logout.js"></script>
      <script>
        function submitFeedback(teacherId, emoji) {
          alert('Feedback submitted for ' + document.getElementById(teacherId).previousElementSibling.innerText + ': ' + emoji);
          
          // Add the clicked class for the animation effect
          document.getElementById(teacherId).classList.add('emoji-clicked');
          
          // Remove the clicked class after the animation completes
          setTimeout(function() {
            document.getElementById(teacherId).classList.remove('emoji-clicked');
          }, 500);
        }
      </script>
</body>
</html>



