<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to the login page
    header("Location: login.html");
    exit();
}

// Get user information from session variables
$id = $_SESSION['id'];
$name = $_SESSION['name'];
$javac = $_SESSION['javac'];
$befac = $_SESSION['befac'];
$dmc= $_SESSION['dmc'];
$osc= $_SESSION['osc'];
$dbmsc = $_SESSION['dbmsc'];
$all = $_SESSION['all'];
$present = $_SESSION['present'];
$absent = $_SESSION['absent'];
$percentage = $_SESSION['percentage'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="scss.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .chart-container {
            position: relative;
            width: 80%;
            max-width: 800px;
            margin: 20px auto;
           
            padding: 20px;
           
        }

        canvas {
            display: block;
        }
    </style>
</head>
<body>
    <div class="student">
        <nav>
        <ul>
            <h1>Student Dashboard</h1>
            <li><a href="sstudent.php">Student</a></li>
            <li><a href="sattendence.php">Attendance</a></li>
            <li><a href="sper.php">Performance</a></li>
            <li><a href="snotice.php">Notice</a></li>
            <li><a href="sfeedback.php">Feedback</a></li>
            <li><button type="button" onclick="logout()">LogOut</button></li>
        </ul>
        </nav>
        <h2>Attendance</h2>
    </div>
    <div class="container mt-5">
       <table class="table table-striped text-center mx-auto" style="width: auto;">
           <thead>
               <tr>
                   <th scope="col">SI No</th>
                   <th scope="col">Id</th>
                   <th scope="col">Name</th>
                   <th scope="col">JAVA</th>
                   <th scope="col">BEFA</th>
                   <th scope="col">DBMS</th>
                   <th scope="col">DM</th>
                   <th scope="col">OS</th>
                   <th scope="col">Totalclass</th>
                   <th scope="col">PRESENT</th>
                   <th scope="col">ABSENT</th>
                   <th scope="col">PERCENTAGE</th>
               </tr>
           </thead>
           <tbody>
               <tr>
                   <th scope="row">1</th>
                   <td><?php echo htmlspecialchars($id); ?></td>
                   <td><?php echo htmlspecialchars($name); ?></td>
                   <td><?php echo htmlspecialchars($javac); ?></td>
                   <td><?php echo htmlspecialchars($befac); ?></td>
                   <td><?php echo htmlspecialchars($dbmsc); ?></td>
                   <td><?php echo htmlspecialchars($dmc); ?></td>
                   <td><?php echo htmlspecialchars($osc); ?></td>
                   <td><?php echo htmlspecialchars($all); ?></td>
                   <td><?php echo htmlspecialchars($osc + $dbmsc + $javac + $befac + $dmc); ?></td>
                   <td><?php echo htmlspecialchars($all - ($osc + $dbmsc + $javac + $befac + $dmc)); ?></td>
                   <td>
                       <?php 
                           $totalScore = $osc + $dbmsc + $javac + $befac + $dmc;
                           $percentage = ($all > 0) ? ($totalScore / $all) * 100 : 0;
                           echo htmlspecialchars(number_format($percentage, 2).'%'); // Format the percentage to 2 decimal places
                       ?>
                   </td>
               </tr>
           </tbody>
       </table>
   </div>

    <div class="container mt-5">
        <div class="chart-container">
            <canvas id="marksChart"></canvas>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Data for the donut chart
        const labels = ['Java', 'BEFA', 'DBMS', 'DM', 'OS'];
        const data = {
            labels: labels,
            datasets: [{
                label: 'PresentClass',
                data: [
                    <?php echo $javac; ?>,
                    <?php echo $befac; ?>,
                    <?php echo $dbmsc; ?>,
                    <?php echo $dmc; ?>,
                    <?php echo $osc; ?>
                ],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        };

        const config = {
            type: 'doughnut',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top', // Position legend at the top
                    }
                }
            }
        };

        const marksChart = new Chart(
            document.getElementById('marksChart'),
            config
        );
    </script>
    <script src="logout.js"></script>
</body>
</html>

