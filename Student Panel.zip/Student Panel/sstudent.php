<?php
// Start the session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to the login page
    header("Location: login.html");
    exit();
}

// Get user information from session variables
$id = $_SESSION['id'];
$username = $_SESSION['username'];
$gender = $_SESSION['gender'];
$dob = $_SESSION['DOB'];
$mobile = $_SESSION['mobile']; // Use the correct session variable name
$email = $_SESSION['email']; // Use the correct session variable name
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="scss.css">
</head>
<body>
    <div class="student">
        <nav>
            <h1>Student Dashboard</h1>
        <ul>
            
            <li><a href="sstudent.php">Student</a></li>
            <li><a href="sattendence.php">Attendence</a></li>
            <li><a href="sper.php">Performance</a></li>
            <li><a href="snotice.php">Notice</a></li>
            <li><a href="sfeedback.php">Feedback</a></li>
            <li><button type="button" onclick="logout()">LogOut</button></li>
        </ul>
        </nav>
        <h2>Student</h2>
        <script src="logout.js"></script>
      </div>
      <div class="container mt-5">
       
        <table class="table table-striped text-center mx-auto" style="width: auto;">
            <thead>
                <tr>
                    <th scope="col">SI No</th>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Date of Birth</th>
                    <th scope="col">Email</th>
                    <th scope="col">Mobile</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">1</th>
                    <td><?php echo htmlspecialchars($id); ?></td>
                    <td><?php echo htmlspecialchars($username); ?></td>
                    <td><?php echo htmlspecialchars($gender); ?></td>
                    <td><?php echo htmlspecialchars($dob); ?></td>
                    <td><?php echo htmlspecialchars($email); ?></td>
                    <td><?php echo htmlspecialchars($mobile); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</body>
</html>
