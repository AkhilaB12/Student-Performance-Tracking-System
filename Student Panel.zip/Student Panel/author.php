<?php
session_start();

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate username and password
    $conn = new mysqli("localhost", "root", "", "crudoperation");

    // Check for database connection errors
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute SQL query to check if username and password match
    $stmt = $conn->prepare("SELECT * FROM crud WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    // If a matching user is found, set session variables and redirect to dashboard
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $_SESSION['id'] = $row['Id']; 
        $_SESSION['name'] = $row['Name']; 
        $_SESSION['username'] = $row['Username']; // Use the correct field name from the database
        $_SESSION['gender'] = $row['Gender']; // Use the correct field name from the database
        $_SESSION['DOB'] = $row['DOB'];
        $_SESSION['email'] = $row['Email'];
         // Use the correct field name from the database
        $_SESSION['mobile'] = $row['Mobile']; // Use the correct field name from the database
        $_SESSION['java'] = $row['JAVA'];
        $_SESSION['dm'] = $row['DM'];
        $_SESSION['befa'] = $row['BEFA'];
        $_SESSION['dbms'] = $row['DBMS'];
        $_SESSION['os'] = $row['OS'];
        $_SESSION['total'] = $row['TotalMarks'];
        $_SESSION['javac'] = $row['javaclass'];
        $_SESSION['dmc'] = $row['DM-A'];
        $_SESSION['osc'] = $row['OSclass'];
        $_SESSION['befac'] = $row['BEFAclass'];
        $_SESSION['dbmsc'] = $row['DBMS-A'];
        $_SESSION['all'] = $row['TotalClass'];
        $_SESSION['present'] = $row['Present'];
        $_SESSION['absent'] = $row['Absent'];
        $_SESSION['percentage'] = $row['Percentage'];

        // Redirect to dashboard
        header("Location: studentdashh.php");
        exit();
    } else {
        // If login fails, redirect back to login page with an error message
        header("Location: login.html?error=1");
        exit();
    }
}
?>

