<?php
include 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Operation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="boardadmin.css">
    <style>
        .container {
            margin-left: 185px; 
          
        }
        th, td {
            border: 1px solid #dee2e6;
        }
        .centered {
            display: flex;
          
            margin-left: 30px; /* Adjust this value to fine-tune the positioning */
        }
        .btn a {
            text-decoration: none; /* Remove underline from link */
        }
    </style>
</head>
<body>
    <div class="container">
    <div class="centered">
        <button class="btn btn-info my-5"><a href="user.php" class="text-light">Add Student</a></button></div>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">SI No</th>
                    <th scope="col">ID</th>
                    <th scope="col">Name</th>
                    <th scope="col">DOB</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Email</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Username</th>
                    <th scope="col">Password</th>
                    <th scope="col">Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM crud";
                $result = mysqli_query($conn, $sql);
                if ($result && mysqli_num_rows($result) > 0) {
                    $count = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row["Id"];
                        $Name = $row["Name"];
                        $dob = $row["DOB"];
                        $gender = $row["Gender"];
                        $email = $row["Email"];
                        $mobile = $row["Mobile"];
                        $username = $row["Username"];
                        $password = $row["Password"];
                        echo '<tr>
                            <td>' . $count++ . '</td>
                            <td>' . $id . '</td>
                            <td>' . $Name . '</td>
                            <td>' . $dob . '</td>
                            <td>' . $gender . '</td>
                            <td>' . $email . '</td>
                            <td>' . $mobile . '</td>
                            <td>' . $username . '</td>
                            <td>' . $password . '</td>
                            <td>
                            <button class="btn btn-primary btn-sm style="text-decoration: none ;"><a href="update.php?id='.$id.'"class="text-light">Update </a>
                            <button class="btn btn-danger btn-sm "><a href="delete.php?id='.$id.'"class="text-light ">Delete</a>
                            </td>
                          </tr>';
                    }
                } 
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
