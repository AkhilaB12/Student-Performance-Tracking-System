<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="scss.css">
</head>
<body>
    <div class="student">
        <nav>
            
            <h1>Student Dashboard</h1>
        <ul>
            
            <li><a href="sstudent.php">Student</a></li>
            <li><a href="sattendence.php">Attendence</a></li>
            <li><a href="snotice.php">Notice</a></li>
            <li><a href="sper.php">Performance</a></li>
            <li><a href="sfeedback.php">Feedback</a></li>
            <li><button type="button" onclick="logout()">LogOut</button></li>
        </ul>
        </nav>
        <script src="logout.js"></script>
      </div>
</body>
</html>