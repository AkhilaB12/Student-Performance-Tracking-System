<?php
include 'connect.php'; // Assuming 'connect.php' contains your database connection code

if(isset($_POST['submit'])) {
    // Retrieve form data
    $Name = $_POST['Name'];
    $DOB = $_POST['DOB'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare and execute SQL query
    $sql = "INSERT INTO crud (Name, DOB, gender, email, mobile, username, password)
            VALUES ('$Name', '$DOB', '$gender', '$email', '$mobile', '$username', '$password')";
    $result = mysqli_query($conn, $sql);

    // Check if query executed successfully
    if($result) {
        header("location:student.php");
    } else {
        // Display error message if query failed
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Operation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
</head>
<body>
    <div class="container my-5">
        <form method="post" action="user.php"> <!-- Assuming your PHP script is named user.php -->
            <div class="mb-3">
                <label for="Name">Name</label>
                <input type="text" class="form-control" id="Name" placeholder="Enter your name" name="Name">    
            </div>
            <div class="mb-3">
                <label for="DOB">DOB</label>
                <input type="date" class="form-control" id="DOB" placeholder="DD/MM/YYYY" name="DOB">    
            </div>
            <div class="mb-3">
                <label for="gender">Gender</label>
                <input type="text" class="form-control" id="gender" name="gender" placeholder="Enter the gender">
            </div>
            <div class="mb-3">
                <label for="email">Email</label>
                <input type="text" class="form-control" id="email" placeholder="abc@gmail.com" name="email">
            </div>
            <div class="mb-3">
                <label for="mobile">Mobile</label>
                <input type="text" class="form-control" id="mobile" placeholder="Enter mobile no" name="mobile">
            </div>
            <div class="mb-3">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="Enter the username">
            </div>
            <div class="mb-3">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" placeholder="Enter your password" name="password">
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
        </form>
    </div>
</body>
</html>
