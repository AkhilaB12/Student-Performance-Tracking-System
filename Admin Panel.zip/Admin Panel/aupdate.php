<?php
include 'connect.php';

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM crud WHERE Id ='$id'";
    $result = mysqli_query($conn, $query);
    if(!$result) {
       die("Failed: " . mysqli_error($conn));
    } else {
        $row = mysqli_fetch_assoc($result);
    }
}

if(isset($_POST["update_student"])) {
    if(isset($_GET['id'])) {
        $id = $_GET['id'];
    }
    $name = $_POST['Name'];
    $java = $_POST['javaclass'];
    $os = $_POST['OSclass'];
    $dm = $_POST['DM-A'];
    $befa = $_POST['BEFAclass'];
    $dbms = $_POST['DBMS-A'];
    $totalClass = $_POST['TotalClass'];
    $present = $_POST['Present'];
    $absent = $_POST['Absent'];
    $percentage = $_POST['Percentage'];

    $query = "UPDATE crud SET Name='$name', javaclass='$java', OSclass='$os', `DM-A`='$dm', BEFAclass='$befa', `DBMS-A`='$dbms', TotalClass='$totalClass', Present='$present', Absent='$absent', Percentage='$percentage' WHERE Id='$id'";

    $result = mysqli_query($conn, $query);
    if(!$result) {
       die("Failed: " . mysqli_error($conn));
    } else {
       header("location:attendence.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Student Record</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
</head>
<body>
<div class="container my-5">
    <form method="post" action="aupdate.php?id=<?php echo $id; ?>">
        <div class="mb-3">
            <label for="Name">Name</label>
            <input type="text" class="form-control" id="Name" placeholder="Enter your name" name="Name" value="<?php echo $row["Name"]; ?>">    
        </div>
        <div class="mb-3">
            <label for="javaclass">Java Class</label>
            <input type="text" class="form-control" id="javaclass" placeholder="Enter number of Java classes" name="javaclass" value="<?php echo $row["javaclass"];?>">    
        </div>
        <div class="mb-3">
            <label for="DBMS-A">DBMS-A</label>
            <input type="text" class="form-control" id="DBMS-A" name="DBMS-A" placeholder="Enter number of DBMS-A classes" value="<?php echo $row["DBMS-A"];?>">
        </div>
        <div class="mb-3">
            <label for="OSclass">OS Class</label>
            <input type="text" class="form-control" id="osclass" name="OSclass" placeholder="Enter number of OS classes"  value="<?php echo $row["OSclass"];?>">
        </div>
        <div class="mb-3">
            <label for="DMclass">DM-A</label>
            <input type="text" class="form-control" id="DM-A" name="DM-A" placeholder="Enter number of DM-A classes"  value="<?php echo $row["DM-A"]; ?>">
        </div>
        <div class="mb-3">
            <label for="BEFAclass">BEFA Class</label>
            <input type="text" class="form-control" id="BEFAclass" name="BEFAclass" placeholder="Enter number of BEFA classes" value="<?php echo $row["BEFAclass"]; ?>">
        </div>
        <div class="mb-3">
            <label for="TotalClass">Total Class</label>
            <input type="text" class="form-control" id="TotalClass" name="TotalClass" placeholder="Enter total number of classes" value="<?php echo $row["TotalClass"]; ?>">
        </div>
        <div class="mb-3">
            <label for="Present">Present</label>
            <input type="text" class="form-control" id="Present" name="Present" placeholder="Enter number of classes present" value="<?php echo $row["Present"];?>">
        </div>
        <div class="mb-3">
            <label for="Absent">Absent</label>
            <input type="text" class="form-control" id="Absent" name="Absent" placeholder="Enter number of classes absent" value="<?php echo $row["Absent"]; ?>">
        </div>
        <div class="mb-3">
            <label for="Percentage">Percentage</label>
            <input type="text" class="form-control" id="Percentage" name="Percentage" placeholder="Enter percentage" value="<?php echo $row["Percentage"]; ?>">
        </div>
        <input type="submit" class="btn btn-success" name="update_student" value="Update">
    </form>
</div>
</body>
</html>