<?php
include 'connect.php';

if(isset($_GET['id'])) {
    $id = $_GET['id'];

    $query = "SELECT * FROM crud WHERE Id='$id'";
    $result = mysqli_query($conn, $query);

    if(!$result) {
        die("Failed to fetch record: " . mysqli_error($conn));
    } else {
        $row = mysqli_fetch_assoc($result);
    }
}

if(isset($_POST["update_student"])) {
    $id = $_POST['id']; // Get the ID from the form submission
    $Name = $_POST['Name'];
    $dob = $_POST['DOB'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = "UPDATE crud SET Name='$Name', DOB='$dob', Gender='$gender', Email='$email', Mobile='$mobile', Username='$username', Password='$password' WHERE Id='$id'";
    $result = mysqli_query($conn, $query);

    if(!$result) {
        die("Failed to update record: " . mysqli_error($conn));
    } else {
        header("Location:student.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Student</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
</head>
<body>
    <div class="container my-5">
        <h2>Update Student Record</h2>
        <form method="post" action="update.php">
            <input type="hidden" name="id" value="<?php echo $row['Id']; ?>"> <!-- Hidden input to send ID -->
            <div class="mb-3">
                <label for="Name">Name</label>
                <input type="text" class="form-control" id="Name" name="Name" value="<?php echo $row['Name']; ?>">
            </div>
            <div class="mb-3">
                <label for="DOB">DOB</label>
                <input type="date" class="form-control" id="DOB" name="DOB" value="<?php echo $row['DOB']; ?>">
            </div>
            <div class="mb-3">
                <label for="gender">Gender</label>
                <input type="text" class="form-control" id="gender" name="gender" value="<?php echo $row['Gender']; ?>">
            </div>
            <div class="mb-3">
                <label for="email">Email</label>
                <input type="text" class="form-control" id="email" name="email" value="<?php echo $row['Email']; ?>">
            </div>
            <div class="mb-3">
                <label for="mobile">Mobile</label>
                <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $row['Mobile']; ?>">
            </div>
            <div class="mb-3">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo $row['Username']; ?>">
            </div>
            <div class="mb-3">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" value="<?php echo $row['Password']; ?>">
            </div>
            <button type="submit" class="btn btn-primary" name="update_student">Update</button>
        </form>
    </div>
</body>
</html>


