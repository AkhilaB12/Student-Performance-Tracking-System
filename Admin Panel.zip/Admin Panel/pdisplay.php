<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Operation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <!-- Chart.js library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .container {
            margin-left: 185px; 
        }
        th, td {
            border: 1px solid #dee2e6;
        }
        .centered {
            display: flex;
            margin-left: 30px; /* Adjust this value to fine-tune the positioning */
        }
        .btn a {
            text-decoration: none; /* Remove underline from link */
        }
        .col {
            font-style: initial;
            color: aqua;
        }
        /* Override Bootstrap table background */
        .table {
            background-color: white;
        }
        /* Style for the chart canvas */
        #chartContainer {
            margin: 0 auto; /* Center horizontally */
            display: block; /* Ensures the chart container takes up the full width */
            width: 80%; /* Adjust width as needed */
            max-width: 400px; /* Adjust max-width as needed */
            height: 400px; /* Adjust height as needed */
            margin-top: 120px; /* Adjust margin-top as needed */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="centered">
            <button class="btn btn-info my-5"><a href="puser.php" class="text-light">Add Student</a></button>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col" class="col">SI No</th>
                    <th scope="col" class="col">ID</th>
                    <th scope="col" class="col">Name</th>
                    <th scope="col" class="col">JAVA</th>
                    <th scope="col" class="col">DBMS</th>
                    <th scope="col" class="col">OS</th>
                    <th scope="col" class="col">BEFA</th>
                    <th scope="col" class="col">DM</th>
                    <th scope="col" class="col">Total Marks</th> <!-- New column -->
                    <th scope="col" class="col">Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include "connect.php";
                $sql = "SELECT * FROM crud";
                $result = mysqli_query($conn, $sql);
                $studentNames = [];
                $totalMarksData = [];
                if ($result && mysqli_num_rows($result) > 0) {
                    $count = 1;
                    while ($row = mysqli_fetch_assoc($result)) {
                        $id = $row["Id"];
                        $name = $row["Name"];
                        $java = $row["JAVA"];
                        $dbms = $row["DBMS"];
                        $os = $row["OS"];
                        $befa = $row["BEFA"];
                        $dm = $row["DM"];
                        $totalMarks = $java + $dbms + $os + $befa + $dm; // Calculate total marks
                        echo '<tr>
                            <td>' . $count++ . '</td>
                            <td>' . $id . '</td>
                            <td>' . $name . '</td>
                            <td>' . $java . '</td>
                            <td>' . $dbms . '</td>
                            <td>' . $os . '</td>
                            <td>' . $befa . '</td>
                            <td>' . $dm . '</td>
                            <td>' . $totalMarks . '</td> <!-- New column -->
                            <td>
                                <button class="btn btn-primary btn-sm"><a href="pupdate.php?id='.$id.'" class="text-light">Update</a></button>
                                <button class="btn btn-danger btn-sm"><a href="delete.php?id='.$id.'" class="text-light">Delete</a></button>
                            </td>
                        </tr>';
                        $studentNames[] = $name;
                        $totalMarksData[] = $totalMarks;
                    }
                }
                ?>
            </tbody>
        </table>
        
        <!-- Canvas for the chart -->
        <div id="chartContainer">
            <canvas id="totalMarksChart"></canvas>
        </div>
    </div>

    <script>
        // Prepare data for the chart
        const totalMarksData = <?php echo json_encode($totalMarksData); ?>;
        const studentNames = <?php echo json_encode($studentNames); ?>;
        
        // Create the bar chart
        let ctx = document.getElementById('totalMarksChart').getContext('2d');
        let totalMarksChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: studentNames, // Use student names as labels
                datasets: [{
                    label: 'Total Marks',
                    data: totalMarksData,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)', // Bar color
                    borderColor: 'rgba(255, 99, 132, 1)', // Border color
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top', // Position legend at the top
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true // Start y-axis at zero
                    }
                }
            }
        });
    </script>
</body>
</html>




