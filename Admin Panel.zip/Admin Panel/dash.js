// dash.js

// Fetch student counts from the server and update the dashboard
fetch('/fetch_student_counts')
    .then(response => response.json())
    .then(data => {
        const totalStudents = data.total_students;
        const maleStudents = data.male_students;
        const femaleStudents = data.female_students;

        // Display student counts on the dashboard
        document.getElementById('studentCounts').innerHTML = `
            <p>Total Students: ${totalStudents}</p>
            <p>Male Students: ${maleStudents}</p>
            <p>Female Students: ${femaleStudents}</p>
        `;
    })
    .catch(error => console.error('Error fetching student counts:', error));