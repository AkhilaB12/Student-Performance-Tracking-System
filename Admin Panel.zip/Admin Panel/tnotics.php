<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="boardadmin.css"> <!-- Ensure this path is correct -->
    <style>
  

        .admin-panel {
            text-align: center;
            margin: 20px auto;
        }

        .student-panel {
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .notice {
            border: 1px solid #ccc;
            margin: 20px auto;
            padding: 10px;
            max-width: 600px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }

  

        .date {
            font-style: italic;
        }

  
    </style>
</head>
<body>
    <nav>
        <h1>Admin Dashboard</h1>
        <ul>
            <li><a href="dash.php">Dashboard</a></li>
            <li><a href="student.php">Student</a></li>
            <li><a href="attendence.php">Attendance</a></li>
            <li><a href="per.php">Performance</a></li>
            <li><a href="tnotics.php">Notices</a></li>
            <li><button type="button" onclick="logout()">LogOut</button></li>
        </ul>
    </nav>
    <div class="admin-panel">
        <h2>Notice</h2>
        <form id="noticeForm">
            <textarea id="noticeText" name="noticeText" rows="19" cols="80" placeholder="Enter notice here"></textarea><br>
            <button type="button" onclick="submitNotice()">Submit</button>
        </form>
    </div>

    <script>
        function submitNotice() {
            var noticeText = document.getElementById('noticeText').value;
            if (noticeText.trim() !== '') {
                var date = getCurrentDate();
                var newNotice = { text: noticeText, date: date };
                var notices = localStorage.getItem('notices') ? JSON.parse(localStorage.getItem('notices')) : [];
                notices.push(newNotice);
                localStorage.setItem('notices', JSON.stringify(notices));
                alert('Notice submitted successfully.');
                // Clear input field after submission
                document.getElementById('noticeText').value = '';
            } else {
                alert('Please enter a notice before submitting.');
            }
        }

        function getCurrentDate() {
            var date = new Date();
            var day = String(date.getDate()).padStart(2, '0');
            var month = String(date.getMonth() + 1).padStart(2, '0');
            var year = date.getFullYear();
            return `${day}/${month}/${year}`;
        }

        function logout() {
            // Add your logout logic here
            alert('Logout functionality not implemented.');
        }
    </script>
    <script src="logout.js"></script> <!-- Ensure this file exists and contains the logout functionality -->
</body>
</html>

