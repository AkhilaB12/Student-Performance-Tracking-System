<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="boardadmin.css">
</head>
<body>
    <div class="admin">
        <nav>
            <h1>Admin Dashoard</h1>
            <ul>
                <li><a href="dash.php">Dashboard</a></li>
                <li><a href="student.php">Student</a></li>
                <li><a href="attendence.php">Attendance</a></li>
                <li><a href="per.php">Performance</a></li>
                <li><a href="tnotics.php">Notices</a></li>
                <li><button type="button" onclick="logout()">LogOut</button></li>
            </ul>
        </nav>
        <h2>performance</h2>
        <?php include "pdisplay.php";?>
    </div>
    <script src="logout.js"></script>
</body>
</html>