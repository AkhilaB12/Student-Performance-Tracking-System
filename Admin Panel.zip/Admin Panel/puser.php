<?php
include 'connect.php'; // Assuming 'connect.php' contains your database connection code

if(isset($_POST['submit'])) {
    // Retrieve form data
    $name = $_POST['Name'];
    $java= $_POST['JAVA'];
    $os = $_POST['OS'];
    $dm = $_POST['DM'];
    $befa = $_POST['BEFA'];
    $dbms = $_POST['DBMS'];
  

    // Prepare and execute SQL query
    $sql = "INSERT INTO crud (name, JAVA, OS, DBMS, BEFA, DM)
            VALUES ('$name', '$java', '$os', '$dbms', '$befa, '$dm')";
    $result = mysqli_query($conn, $sql);

    // Check if query executed successfully
    if($result) {
        header("location:per.php");
    } else {
        // Display error message if query failed
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Operation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
</head>
<body>
    <div class="container my-5">
        <form method="post" action="user.php"> <!-- Assuming your PHP script is named user.php -->
            <div class="mb-3">
                <label for="Name">Name</label>
                <input type="text" class="form-control" id="Name" placeholder="Enter your name" name="Name">    
            </div>
            <div class="mb-3">
                <label for="java">JAVA</label>
                <input type="text" class="form-control" id="java" placeholder="Enter marks" name="java">    
            </div>
            <div class="mb-3">
                <label for="java">OS</label>
                <input type="text" class="form-control" id="os" name="os" placeholder="Enter marks">
            </div>
            <div class="mb-3">
                <label for="dbms">DBMS</label>
                <input type="text" class="form-control" id="dbms" placeholder="Enter marks" name="dbms">
            </div>
            <div class="mb-3">
                <label for="dm">DM</label>
                <input type="text" class="form-control" id="dm" placeholder="Enter marks" name="dm">
            </div>
            <div class="mb-3">
                <label for="username">BEFA</label>
                <input type="text" class="form-control" id="username" name="befa" placeholder="Enter marks">
            </div>
    
            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
        </form>
    </div>
</body>
</html>