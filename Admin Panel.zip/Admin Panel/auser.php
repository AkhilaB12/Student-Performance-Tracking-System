<?php
include 'connect.php'; // Assuming 'connect.php' contains your database connection code

if(isset($_POST['submit'])) {
    // Retrieve form data
    $name = $_POST['Name'];
    $Javaclass= $_POST['Javaclass'];
    $OSclass=$_POST['OSclass'];
    $dbmsclass=$_post[' DBMSclass'];
    $befaclass=$_post['BEFAclass'];
    $dmclass= $_POST['DMclass'];
    $totalclass= $_POST['TotalClass'];
    $Present= $_POST['Present'];
    $Absent= $_POST['Absent'];
    $Percentagee= $_POST['Percentage'];
        // Prepare and execute SQL query
    $sql = "INSERT INTO crud (name,Javaclass,OSclass, DBMSclass, BEFAclass,DMclass,TotalClass,Present,Absent,Percentage)
            VALUES ('$name', '$Javaclass', ' $OSclass', '$dbmsclass', '$befaclass', ' $dmclass', $totalclass, $Present,  $Absent,$Percentage)";
    $result = mysqli_query($conn, $sql);

    // Check if query executed successfully
    if($result) {
        header("location:attendence.html");
    } else {
        // Display error message if query failed
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Operation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
</head>
<body>
    <div class="container my-5">
        <form method="post" action="user.php"> <!-- Assuming your PHP script is named user.php -->
            <div class="mb-3">
                <label for="Name">Name</label>
                <input type="text" class="form-control" id="Name" placeholder="Enter your name" name="Name">    
            </div>
            <div class="mb-3">
                <label for="Javaclass">Javaclass</label>
                <input type="text" class="form-control" id="Javaclass"placeholder="Enter no of class presented" name="Javaclass">    
            </div>
            <div class="mb-3">
                <label for="DBMSclass">DBMSclass</label>
                <input type="text" class="form-control" id="dbmsclass" name="javaclass" placeholder="Enter no of class presented">
            </div>
            <div class="mb-3">
                <label for="OSclass">OSclass</label>
                <input type="text" class="form-control" id="OSclass" placeholder="Enter no of class presented" name="email">
            </div>
            <div class="mb-3">
                <label for="DMclass">DMclass</label>
                <input type="text" class="form-control" id="dmclass" placeholder="Enter no of class presented" name="mobile">
            </div>
            <div class="mb-3">
                <label for="BEFAclass">BEFAclass</label>
                <input type="text" class="form-control" id="befaclass" name="befaclass" placeholder="Enter no of class presented">
            </div>
            <div class="mb-3">
                <label for="TotalClass">TotalClass</label>
                <input type="text" class="form-control" id="totalclass" name="totalclass" placeholder="Enter total  class">
            </div>
            <div class="mb-3">
                <label for="Present">Present</label>
                <input type="text" class="form-control" id="Present" name="Present" placeholder="Enter no of  class prsented">
            </div>
            <div class="mb-3">
                <label for="Absent">Absent</label>
                <input type="text" class="form-control" id="Absent" name="Absent" placeholder="Enter no of  class absent">
            </div>
            <div class="mb-3">
                <label for="Attendence%">Percentage</label>
                <input type="text" class="form-control" id="Percentage" name="Percentage" placeholder="Enter no of  class absent">
            </div>

            <button type="submit" class="btn btn-primary" name="submit">Submit</button>
        </form>
    </div>
</body>
</html>
