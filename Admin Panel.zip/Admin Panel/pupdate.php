<?php include 'connect.php'; ?>

<?php

if(isset($_GET['id'])) {
    $id = $_GET['id'];

    $query="select * from crud where  Id ='$id'";
    $result = mysqli_query($conn, $query);
    if(!$result) {
       die("failed" . mysqli_error($conn));
    } else {
        $row = mysqli_fetch_assoc($result);
    }
}

if(isset($_POST["update_student"])) {
    if(isset($_GET['id_new'])) {
        $idnew = $_GET['id_new'];
    }
    $name = $_POST['Name'];
    $java = $_POST['JAVA'];
    $os = $_POST['OS'];
    $dm = $_POST['DM'];
    $befa = $_POST['BEFA'];
    $dbms = $_POST['DBMS'];
    
    $query = "update crud set Name='$name', JAVA='$java', OS='$os', DM='$dm', BEFA='$befa', DBMS='$dbms' where id= '$idnew'";
    $result = mysqli_query($conn, $query);
    if(!$result) {
       die("failed" . mysqli_error($conn));
    } else {
       header("location:per.php");
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crud Operation</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
</head>
<body>

<div class="container my-5">
    <form method="post" action="pupdate.php?id_new=<?php echo $id; ?>"> 
        <div class="mb-3">
            <label for="Name">Name</label>
            <input type="text" class="form-control" id="Name" placeholder="Enter your name" name="Name" value="<?php echo $row["Name"]; ?>">    
        </div>
        <div class="mb-3">
            <label for="java">JAVA</label>
            <input type="text" class="form-control" id="java" placeholder="Enter marks" name="JAVA" value="<?php echo $row["JAVA"]; ?>">    
        </div>
        <div class="mb-3">
            <label for="java">OS</label>
            <input type="text" class="form-control" id="os" name="OS" placeholder="Enter marks" value="<?php echo $row["OS"]; ?>">
        </div>
        <div class="mb-3">
            <label for="dbms">DBMS</label>
            <input type="text" class="form-control" id="dbms" placeholder="Enter marks" name="DBMS" value="<?php echo $row["DBMS"]; ?>" >
        </div>
        <div class="mb-3">
            <label for="dm">DM</label>
            <input type="text" class="form-control" id="dm" placeholder="Enter marks" name="DM" value="<?php echo $row["DM"]; ?>">
        </div>
        <div class="mb-3">
            <label for="username">BEFA</label>
            <input type="text" class="form-control" id="username" name="BEFA" placeholder="Enter marks" value="<?php echo $row["BEFA"]; ?>">
        </div>
        <input type="submit" class="btn btn-success" name="update_student" value="update">
    </form>
</div>
</body>
</html>
    