<?php
include 'connect.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0
    ,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600;1,700&displa
    y=swap" rel="stylesheet">
   
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-...">
    <title>project</title>
</head>
<body>
<section class="header">
    <nav>
        <div class="nav-links">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="about.html">about</a></li>
            <li><a href="services.html">services</a></li>
            <li><a href="contact.html">contact us</a></li>
            <a href="login.html" class="btn">Login</a>
         </ul>
         </div>
        </nav>
        <div class="content">
            <h1>Hello Students</h1>
            <h4>Welcome to Class<span>Insight</span></h4>
            <h3>Where you can know your <span>PERFORMANCE</span></h3>
        </div>
        </div>   
</section>
<section class="about">
    <div class="main">
        <div class="about-text">
            <h2>About</h2>
            <h5>Class <span>Insight</span></h5>
            <p>The portal is a comprehensive platform that offers a 360-degree view of student
                life and performance within an academic institution. It provides holistic
                performance insights, including students' engagement in extracurricular activities,
                future performance predictions, career placement optimization, and an instant feedback
                mechanism. The portal uses data analytics to identify areas of improvement and support 
                students before assessments. It also offers personalized learning paths based on individual
                student performance, ensuring a more effective and inclusive learning environment. The portal
                also extends access to a dedicated parent interface, allowing parents to actively participate 
                in tracking their child's progress and collaborating with educators. This holistic approach 
                positions the educational institution at the forefront of fostering academic excellence and the 
                overall growth and potential of each student.</p>
        </div>
    </div>
</section>
<div class="servies">
    <div class="title">
        <h2>Features</h2>
    </div>
    <div class="row">
        <div class="serv-col">
            <i class="fa-solid fa-bars"></i>
            <h6>Class Performance</h6>
            <div class="pra">
            <p>The student portal offers a secure, personalized dashboard for students,
                 allowing them to monitor progress and identify areas for improvement.</p>
            </div>
    </div>
        <div class="serv-col">
            <i class="fa-solid fa-user"></i>
            <h6>Student Info</h6>
            <div class="pra">
            <p>This educational platform provides administrators and teachers with privileged access to comprehensive student information,
                 enhancing administrative efficiency and optimizing educational strategies.</p>
        </div>
    </div>
        <div class="serv-col">
            <i class="fa-solid fa-bell"></i>
            <div class="pra">
            <h6>Notifications</h6>
            <p>The website offers students real-time updates, event circulars, personalized communication,
                interactive channels, a centralized calendar, mobile accessibility, and a sense of ownership</p>
        </div>
    </div>
</div>
<footer>
    <p>Class Insight</p>
    <p>For any queries please contact us</p>
    <div class="social">
        <a href="#"><i class="fa-brands fa-facebook"></i></a>
        <a href="#"><i class="fa-brands fa-instagram"></i></a>
        
    </div>
    
</footer>
</body>
</html>