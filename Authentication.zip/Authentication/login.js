document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("adm").addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent form submission
        loginAdmin(); // Call function to handle admin login
    });

    function loginAdmin() {
        var id = document.getElementById("adminID").value;
        var password = document.getElementById("adminPassword").value;

        // Example admin credentials (replace with actual authentication logic)
        var adminID = "admin";
        var adminPassword = "admin123";

        // Check if the entered credentials match the admin credentials
        if (id === adminID && password === adminPassword) {
            // Redirect to the admin dashboard page
            window.location.href = "admindash.html";
        } else {
            // Display error message for invalid credentials
            var errorMessage = document.getElementById("adminErrorMessage");
            errorMessage.style.display = "block";
        }
    }
});


