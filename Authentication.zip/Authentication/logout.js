function logout() {
    alert("Are you sure you want to logout");
    window.location.href = "index.php"; 
}