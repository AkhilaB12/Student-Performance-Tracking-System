function Admin() {
    var studentForm = document.getElementById("std");
    var adminForm = document.getElementById("adm");

    // Move student form off-screen to the left
    studentForm.style.left = "-100%";
    // Move admin form to the center
    adminForm.style.left = "50%";
}
function Student() {
    var studentForm = document.getElementById("std");
    var adminForm = document.getElementById("adm");

    // Move admin form off-screen to the right
    adminForm.style.left = "200%";
    // Move student form to the center
    studentForm.style.left = "50%";
}
